
<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
   .in{
    margin-left:20px;
   }
   .table{
    background-color: rgba(239, 88, 113, 0.695);
   }
</style>
<body>

<?php
include "links.php";
include "config.php";
?>

<div class="main">
    <div class="sidebar">
        <ul>
        
            <li><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_G1yzSnpguN8hMmYYv_PNQ7SCL3LAJjGqKY4F6874qz0r6SxP7HamogWDivNMUaK2iPg&usqp=CAU" alt=""></li>
            <li><a  href="dashboard.php">Dashboard</a></li>
            <li><a href="card.php">Card</a></li>
            <li class="active"> <a href="enquiry.php"> Enquiry</a></li>
            <li><a href="filtergalaryadd.php">filtergalary</a></li>
            <li>Products</li>
            <li><a href="logout.php">Logout</a></li>
           

        </ul>
    </div>

    <div class="nav-bar">
        <div class="right">
        <ul>
        <input type="text"  value=" search"  class="mx-5 in" >
        <li>Hey <?php echo $_SESSION['login'];?></li> 
        <li><img src="https://media.istockphoto.com/id/1369508766/photo/beautiful-successful-latin-woman-smiling.jpg?s=612x612&w=0&k=20&c=LoznG6eGT42_rs9G1dOLumOTlAveLpuOi_U755l_fqI=" width="50px;" alt=""></li>
        
            </ul>
        </div>
        <!-- <table> -->
            <div class="mx-5">
        <table class="table mt-4 text-light">
    <tr class="bg-light text-dark">
        <td>S.no</td>
        <td>name</td>
        <td>email</td>
        <td>subject</td>
        <td>message</td>
        <td>page</td>
        <td>notification</td>
        <td>DELETE</td>

        <?php
        $sqlu="UPDATE `enquiry` SET `notification`=''";
        mysqli_query($connect,$sqlu);
        $id=0;
    $sql="SELECT * FROM `enquiry` order by `id` desc";
    $result=mysqli_query($connect,$sql);
    while($rohit=mysqli_fetch_assoc($result)){	
        $id++;
    ?>
        <tr <?php if($rohit['message']=="") {
            echo "class='table-danger'";
        }
            ?> >
            
            <td><?php echo $id?></td>
            <td><?php echo $rohit['name'];?></td>
            <td><?php echo $rohit['email'];?></td>
            <td><?php echo $rohit['subject'];?></td>
            <td><?php echo $rohit['message'];?></td>
            <td><?php echo $rohit['page'];?></td>
            <td><?php echo $rohit['notification'];?></td>
            <td><a class="btn btn-danger " href="enquiry.php?id=<?php echo $rohit['id'];?>">Delete</a></td>       
        </tr>
        <?php
        }
        ?>
    </tr>
</table>
    </div>





        <!-- </table> -->

    </div>
</div>

<?php
$id=$_GET['id'];
$delete="DELETE  FROM `enquiry` WHERE `id`='$id'";
mysqli_query($connect,$delete) or die ("connection error");
// header("location:enquiry.php");

?>

    
</body>
</html>