
<?php

session_start();
if(!isset($_SESSION['login'])){
    header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
include "links.php";
?>



<div class="main">
    <div class="sidebar">
        <ul>
            <li><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_G1yzSnpguN8hMmYYv_PNQ7SCL3LAJjGqKY4F6874qz0r6SxP7HamogWDivNMUaK2iPg&usqp=CAU" alt=""></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li class="active"><a href="card.php">Card</a></li>
            <li> <a href="enquiry.php">Enquiry</a></li>
            <li><a href="filtergalaryadd.php">filtergalary</a></li>
            <li>Products</li>

            <li><a href="logout.php">Logout</a></li>

        </ul>
    </div>

    <div class="nav-bar">
        <div class="right">
        <ul>
        <li>Hey <?php echo $_SESSION['login'];?></li> 
        <li><img src="https://media.istockphoto.com/id/1369508766/photo/beautiful-successful-latin-woman-smiling.jpg?s=612x612&w=0&k=20&c=LoznG6eGT42_rs9G1dOLumOTlAveLpuOi_U755l_fqI=" width="50px;" alt=""></li>
        
            </ul>
        </div>

        
        <!-- table start+++++++++++++++ -->
        <div class="px-5">
        <a href="addcard.php"><button  class=" btn btn-primary mb-4">add card</button></a>

       
        <table class="table">
            <tr>
                <td>Id</td>
                <td>Tittle</td>
                <td>Desc</td>
                <td>Icon</td>
                <td>Delete</td>
                <!-- <td>update</td> -->
<?php

include "config.php";
$sql="SELECT * FROM `gift`";
$result=mysqli_query($connect,$sql);
while($rohit=mysqli_fetch_assoc($result)){ 
?>
<tr>
    
    <td><?php  echo $rohit['id'];?></td>
    <td><?php echo $rohit['tittle'];?></td>
    <td><?php echo $rohit['desc'];?></td>
    <td><?php echo $rohit['icon'];?></td>
    
    <td><a class="btn btn-danger " href="delete.php?id=<?php echo $rohit['id'];?>">Delete</a></td>
    <!-- <td><a class="btn btn-warning " href="update.php?id=<?php echo $rohit['id'];?>">update</a></td> -->
</tr>

<?php
}
?>


</tr>
        </table>
</div>
    </div>
</div>
    


</body>
</html>