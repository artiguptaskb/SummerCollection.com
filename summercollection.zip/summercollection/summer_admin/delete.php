<?php
include "config.php";
$id=$_GET['id'];

$delete="DELETE FROM `gift` WHERE `id`='$id'";
mysqli_query($connect,$delete) or die("connection error");
header("location:card.php");

?>