<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    include "config.php";
    $sql="INSERT INTO `filtergalary`(`id`,`cviewname`,`cname`) VALUES (NULL,'course','Course')";
    mysqli_query($connect,$sql);
    ?>
    
</body>
</html>