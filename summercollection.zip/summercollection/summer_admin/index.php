<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php

include "links.php";

?>


    <div id="conteiner">
    <form action="" method="POST" id="form">
        <p>Login Form</p>
        <label>username</label><br>
        <input type="text" id="name" name="name" required><br>
        <label>Password</label><br>
        <input type="text" id="password" name="password"><br><br>
        <label for="remember" class="remember">Remember me</label>
        <input type="checkbox" id="remember" name="Remember">
        <button type="submit" name="login">Login</button>
    </form>
    <div id="error"></div>
    </div>
<?php

if(isset($_POST['login'])){
   $username=$_POST['name'];
    $password=md5($_POST['password']);
     include "config.php";
     $sql="SELECT * FROM `admin`";
     $result=mysqli_query($connect,$sql);
     while($value= mysqli_fetch_assoc($result)){
        if($value['name']==$username && $value['password']==$password){
            session_start();
            $_SESSION['login']=$value['name'];
            header("location:dashboard.php");
        }
     }
}
    ?>




    
</body>
</html>