
<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
   .in{
    margin-left:20px;
   }
</style>
<body>

<?php
include "links.php";
?>

<div class="main">
    <div class="sidebar">
        <ul>
            <li><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_G1yzSnpguN8hMmYYv_PNQ7SCL3LAJjGqKY4F6874qz0r6SxP7HamogWDivNMUaK2iPg&usqp=CAU" alt=""></li>
            <li class="active">Dashboard</li>
            <li><a href="card.php">Card</a></li>
            <li><a href="filtergalaryadd.php">filtergalary</a></li>
            <li> <a href="enquiry.php">
            <?php
            
            include "config.php";
            $sql="SELECT * FROM  `enquiry` WHERE `notification`";
            $result=mysqli_query($connect,$sql);
            $nume=mysqli_num_rows($result);
            echo $nume;
            ?>
            Enquiry

            </a></li>
            <li>Products</li>
            <li><a href="logout.php">Logout</a></li>
         

        </ul>
    </div>

    <div class="nav-bar">
        <div class="right">
        <ul>
        <input type="text"  value=" search"  class="mx-5 in" >
        <li>Hey <?php echo $_SESSION['login'];?></li> 
        <li><img src="https://media.istockphoto.com/id/1369508766/photo/beautiful-successful-latin-woman-smiling.jpg?s=612x612&w=0&k=20&c=LoznG6eGT42_rs9G1dOLumOTlAveLpuOi_U755l_fqI=" width="50px;" alt=""></li>
        
            </ul>
        </div>

    </div>
</div>

    
</body>
</html>