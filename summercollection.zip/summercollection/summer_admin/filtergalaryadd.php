
<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>

    <?php
    include "links.php";
    ?>
    form{
        width: 30%;
        

    }
    form select{
        width: 100%;

    }
    form select .op{
        width: 100%;

    }

</style>

<body>

<?php
include "links.php";
include "config.php";
?>

<div class="main">
    <div class="sidebar">
        <ul>
        
            <li><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_G1yzSnpguN8hMmYYv_PNQ7SCL3LAJjGqKY4F6874qz0r6SxP7HamogWDivNMUaK2iPg&usqp=CAU" alt=""></li>
            <li><a  href="dashboard.php">Dashboard</a></li>
            <li><a href="card.php">Card</a></li>
            <li> <a href="enquiry.php"> Enquiry</a></li>
            <li class="active"><a href="filtergalaryadd.php">filtergalary</a></li>
            <li>Products</li>
            <li><a href="logout.php">Logout</a></li>
           

        </ul>
    </div>

    <div class="nav-bar">
        <div class="right">
        <ul>
        <input type="text"  value=" search"  class="mx-5 in" >
        <li>Hey <?php echo $_SESSION['login'];?></li> 
        <li><img src="https://media.istockphoto.com/id/1369508766/photo/beautiful-successful-latin-woman-smiling.jpg?s=612x612&w=0&k=20&c=LoznG6eGT42_rs9G1dOLumOTlAveLpuOi_U755l_fqI=" width="50px;" alt=""></li>
        
            </ul>
        </div>
       
    </div>
    

    <form  class="me-3 p-5"  method="post" enctype="multipart/form-data">
        <select name="cname" id="" class="select form-control">
            <option value="" class="op" selected disabled>SELECT OPTION</option>
            <?php
            include "config.php";
            $sql="SELECT * FROM `filtergalary`";
            $result=mysqli_query($connect,$sql);
            while($value=mysqli_fetch_assoc($result)){
            ?>

            <option value="<?php echo $value['cname'];?>"><?php echo $value['cname'];?></option>

            <?php
            }
            ?>
        </select>

        <input type="text" placeholder="image title" class="mt-4 p form-control " name="imgtitle">
        <input type="file" name="image" class="mt-4 form-control">
        <input type="submit" name="addproduct" class="mt-4 form-control">
    </form>
    </div>
</div>

<?php
if(isset($_POST['addproduct'])){
$cname=$_POST['cname'];
$imgtittle=$_POST['imgtitle'];
$image=$_FILES['image']['name'];
$imagetmp=$_FILES['image']['tmp_name'];
$destination="image/".$image;
move_uploaded_file($imagetmp,$destination);


// print_r($_FILES['image']);
$sql="INSERT INTO `catproduct`(`id`,`cname`,`imgtitle`,`image`) VALUES (NULL,'$cname','$imgtittle','$image')";
mysqli_query($connect,$sql) or die("error");
}
?>

    
</body>
</html>