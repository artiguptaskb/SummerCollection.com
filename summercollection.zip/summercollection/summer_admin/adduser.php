<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php

include "links.php";
include "config.php";

?>


    <div id="conteiner">
    <form action="" method="POST" id="form">
        <p>RAGISTER  FORM </p>
        <label>email</label><br>
        <input type="text" id="name" name="email" required><br>
        <label>username</label><br>
        <input type="text" id="name" name="name" required><br>
        <label>Password</label><br>
        <input type="text" id="password" name="password"><br><br>
        <button type="submit" name="adduser">RAGISTER</button>
    </form>
    </div>
<?php

if(isset($_POST['adduser'])){
    $email=$_POST['email'];
   $username=$_POST['name'];
    $password=md5($_POST['password']);
    $sql="INSERT INTO `admin`(`email`,`name`,`password`) VALUES ('$email','$username','$password')";
    $result=mysqli_query($connect,$sql);
    header("location:dashboard.php");
        }  
    ?>




    
</body>
</html>