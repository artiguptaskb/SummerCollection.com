<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
include "links.php";

?>

<div class="main">
    <div class="sidebar">
        <ul>
            <li><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_G1yzSnpguN8hMmYYv_PNQ7SCL3LAJjGqKY4F6874qz0r6SxP7HamogWDivNMUaK2iPg&usqp=CAU" alt=""></li>
            <li class="active">Dashboard</li>
            <li><a href="card.php">Card</a></li>
            <li>Enquiry</li>
            <li>Products</li>
            <li><a href="logout.php">Logout</a></li>

        </ul>
    </div>

    <div class="nav-bar">
        <div class="right">
        <ul>
        <li>Hey <?php echo $_SESSION['login'];?></li> 
        <li><img src="https://media.istockphoto.com/id/1369508766/photo/beautiful-successful-latin-woman-smiling.jpg?s=612x612&w=0&k=20&c=LoznG6eGT42_rs9G1dOLumOTlAveLpuOi_U755l_fqI=" width="50px;" alt=""></li>
        
            </ul>
        </div>

    </div>
</div>

<div id="conteiner">
    <form action="" method="POST" id="form">
        <p>add card</p> <br>
        <input type="text" name="icon" placeholder="enter icon"><br>
        <input type="text" name="tittle" placeholder="enter tittle"><br>
        <input type="text" name="desc" placeholder="enter desc"><br>
        <button type="submit" name="submit">submit</button>
    </form>
    </div>
    <?php
   
// Database connection parameters
include "config.php";

// Create connection

// Check connection
if (!$connect) {
    die("Connection failed: " );
}

// Process form data
if (isset($_POST['submit'])) {
    $tittle = $_POST["tittle"];
    $desc = $_POST["desc"];
    $icon = $_POST["icon"];


    // File upload handling
    // $target_dir = "image/";
    // $target_file = $target_dir . basename($_FILES["image"]["name"]);
    // move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

    // SQL query to insert data into the database
    $sql = "INSERT INTO `gift` (`tittle`, `desc`,`icon`) VALUES ('$tittle', '$desc','$icon')";

    // Execute query
    $res =mysqli_query($connect, $sql);
    if ($res === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $connect->error;
    }
}



if( $tittle!="" && $desc!=""  && $desc!=""){
    $sql="INSERT INTO  `gift`(`tittle`,`desc`,`icon`) VALUES ('$tittle','$desc','$icon')";
    mysqli_query($connect,$sql);
    }
    else{

        echo "not successfully";
    }
    ?>





</body>
</html>




