<?php

include "summer_admin/config.php";
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $page=$_POST['fname'];
    $notification=[""];
    $subject=$_POST['subject'];
    $message=$_POST['message'];
    $sql="INSERT INTO `enquiry` (`name`, `email`,`subject`,`message`,`page`,`notification`) VALUES ('$name','$email','$subject','$message','$page','$notification')";
    $res=mysqli_query($connect,$sql);
    header("location:index.php");
    }


?>